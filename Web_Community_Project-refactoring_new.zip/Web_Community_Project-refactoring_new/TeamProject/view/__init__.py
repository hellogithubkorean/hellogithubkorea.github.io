from flask import Blueprint

view = Blueprint("view", __name__)

from view import templates