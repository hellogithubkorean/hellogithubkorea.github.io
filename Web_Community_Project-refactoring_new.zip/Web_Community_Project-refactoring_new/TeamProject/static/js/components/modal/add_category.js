const modal = `<div class='category_modal_back manager_modal_back'>
	<div class='category_modal manager_modal'>
		<div class='category_exit manager_exit'>X</div>
		<div>
			<div class='modal_title'>카테고리 추가</div>
			<div class='modal_sub_container'>
				<span class='modal_sub'>이름</span> 
				<input type='text' class='category_insert_name modal_input' placeholder='카테고리 이름' maxlength='12'>
			</div>
			<button class='category_insert_btn modal_btn'>추가</button>
		</div>
	</div>
	</div>`;

export default modal;