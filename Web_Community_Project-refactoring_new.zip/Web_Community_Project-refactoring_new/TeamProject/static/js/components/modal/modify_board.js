const modal = `<div class="board_modify_modal_back manager_modal_back">
<div class="board_modify_modal manager_modal">
<div class="board_modify_modal_exit manager_exit">X</div>
<div>
    <div class="modal_title">게시판 정보 수정</div>
    <div class="modal_sub_container">
        <span class="board_modify_modal_sub modal_sub">이름</span> 
        <span class="board_modify_modal_name">이름</span>
    </div>
    <div class="modal_sub_container">
        <span class="modal_sub">사진</span>
        <input type="file" class="board_modify_image modal_input" accept="image/*">
    </div>
    <button class="board_modify_modal_btn modal_btn">수정하기</button>
</div>
</div>
</div>`;

export default modal;