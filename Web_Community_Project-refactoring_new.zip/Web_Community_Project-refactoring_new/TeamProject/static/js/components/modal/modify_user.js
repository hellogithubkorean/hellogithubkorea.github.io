const modal = `<div class='user_modal_back manager_modal_back'>
			<div class='user_modal manager_modal'>
			<div class='user_modal_exit manager_exit'>X</div>
			<div>
			<div class='modal_title'>회원 정보 수정</div>
			<div class='modal_sub_container'>
				<span class='modal_sub'>닉네임</span> 
				<input type='text' class='user_modal_input modal_input' placeholder='닉네임 입력'>
			</div>
			<button class='user_modify_btn modal_btn'>수정</button>
			</div>
			</div>
            </div>`;

export default modal;